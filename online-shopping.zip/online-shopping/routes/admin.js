const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const Product = require('../model/Product');
const Order = require('../model/order');
const User = require('../model/User');
// ตั้งค่า multer สำหรับการอัปโหลดไฟล์
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/images');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

// Route สำหรับแสดงหน้าแรกของผู้ดูแลระบบ
router.get('/', async (req, res) => {
    try {
        const products = await Product.find();
        res.render('admin/adminhomepage', { products });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Route สำหรับเพิ่มผลิตภัณฑ์
router.get('/add', (req, res) => {
    res.render('admin/addproduct');
});
router.post('/add', upload.single('image'), async (req, res) => {
    try {
        const { name, price, description, stock } = req.body;

        if (!req.file) {
            return res.status(400).send('Image file is required');
        }

        const product = new Product({
            name,
            price,
            description,
            stock,
            image: req.file.path,
        });

        await product.save();

        res.redirect('/admin?success=Product added successfully!');
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Route สำหรับแก้ไขผลิตภัณฑ์
router.get('/edit/:id', async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).send('Product Not Found');
        }
        res.render('admin/editproduct', { product });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

router.post('/edit/:id', upload.single('image'), async (req, res) => {
    try {
        const { name, price, description, stock } = req.body;
        const updatedProduct = { name, price, description, stock };

        if (req.file) {
            updatedProduct.image = req.file.path;
        }

        await Product.findByIdAndUpdate(req.params.id, updatedProduct, { new: true });

        res.redirect('/admin?success=Product updated successfully!');
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Route สำหรับลบผลิตภัณฑ์
router.post('/delete/:id', async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);
        res.redirect('/admin?success=Product deleted successfully!');
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Route สำหรับแสดงคำสั่งซื้อ
router.get('/orders', async (req, res) => {
    try {
        const orders = await Order.find(); 
        res.render('admin/orders', { orders });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

router.get('/orders/:id', async (req, res) => {
    try {
        const order = await Order.findById(req.params.id);
        if (!order) {
            return res.status(404).send('Order Not Found');
        }

       
        res.render('admin/edit-order', { 
            order, 
            proofOfPayment: order.proofOfPayment 
        });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

router.post('/orders/:id/update-status', async (req, res) => {
    const { status } = req.body; 
    const orderId = req.params.id;

    try {
        // อัปเดตสถานะของออเดอร์
        await Order.findByIdAndUpdate(orderId, { status }, { new: true });
        res.redirect('/admin/orders?success=Order status updated successfully!'); 
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Route สำหรับลบคำสั่งซื้อ
router.post('/orders/:id/delete', async (req, res) => {
    try {
        await Order.findByIdAndDelete(req.params.id);
        res.redirect('/admin/orders?success=Order deleted successfully!');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

//user

router.get('/users', async (req, res) => {
    try {
        const users = await User.find(); // ดึงข้อมูลผู้ใช้ทั้งหมด
        res.render('admin/admin-users', { users }); // ส่งข้อมูล users ไปยังไฟล์ EJS
    } catch (err) {
        res.status(500).send('Error fetching users');
    }
});

router.post('/users/:id/delete', async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).send('User Not Found');
        }
        await User.findByIdAndDelete(req.params.id);
        res.redirect('/admin/users');
    } catch (err) {
        res.status(500).send('Error deleting user');
    }
});


router.get('/users/:id/edit', async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).send('User Not Found');
        }
        res.render('admin/edit-user', { user });
    } catch (err) {
        res.status(500).send('Error fetching user');
    }
});


router.post('/users/:id/edit', async (req, res) => {
    try {
        await User.findByIdAndUpdate(req.params.id, {
            username: req.body.username, // ตรวจสอบว่าคุณอัปเดตชื่อผู้ใช้ด้วย
            email: req.body.email,
            role: req.body.role
        });
        res.redirect('/admin/users');
    } catch (err) {
        res.status(500).send('Error updating user');
    }
});




module.exports = router;
