const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const User = require('../model/User'); 

passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
    const user = await User.findById(id);
    done(null, user);
});

// Google Strategy
passport.use(new GoogleStrategy({
    clientID: '773670547850-cr1ks0do5bq9o3ca4stit59tkl4blhtg.apps.googleusercontent.com',
    clientSecret: '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',
    callbackURL: '/auth/google/redirect',
}, async (accessToken, refreshToken, profile, done) => {
    try {
        let user = await User.findOne({ googleId: profile.id });
        if (!user) {
            user = new User({
                googleId: profile.id,
                username: profile.displayName,
                thumbnail: profile._json.picture,
                email: profile.emails[0].value // เก็บอีเมลที่ดึงจากโปรไฟล์
            });
            await user.save();
        }
        done(null, user);
    } catch (error) {
        console.error(error);
        done(error, null);
    }
}));
