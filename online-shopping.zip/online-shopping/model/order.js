const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    customer: {
        name: { type: String, required: true },
        email: { type: String, required: true },
        address: { type: String, required: true },
    },
    items: [
        {
            product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
            quantity: { type: Number, required: true },
            price: { type: Number, required: true } // ราคาสินค้า ณ เวลาที่สั่ง
        }
    ],
    total: { type: Number, required: true },
    status: {
        type: String,
        enum: ['Pending Payment', 'Processing', 'Shipped', 'Delivered', 'Cancelled'],
        default: 'Pending Payment'
    },
    createdAt: { type: Date, default: Date.now },
    proofOfPayment: { type: String } // ฟิลด์สำหรับเก็บหลักฐานการโอนเงิน (ไม่จำเป็น)
});

const Order = mongoose.model('Order', orderSchema);
module.exports = Order;
