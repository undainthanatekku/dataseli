const express = require('express');
const router = express.Router();
const Product = require('../model/Product'); 
const passport = require('passport');
const User = require('../model/User');
const Order = require('../model/order');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, '../public/images')); 
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname)); 
    }
});

// สร้าง middleware สำหรับ multer
const upload = multer({ storage: storage });

module.exports = (app) => {
    app.post('/upload-proof', upload.single('proof'), (req, res) => {
        const proof = req.file; 
        const orderId = req.body.orderId;

        if (!proof) {
            return res.status(400).send('Please upload a proof file.');
        }



        res.send('Proof uploaded successfully!');
    });

    return router; 
};


// หน้าแรกของสินค้า
router.get('/', async (req, res) => {
    try {
        const products = await Product.find();
        const user = req.user;
        const totalItems = (req.session.cart || []).reduce((total, item) => total + item.quantity, 0);
        res.render('user/homepage', { products, user, totalItems });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});


router.get('/about', async (req, res) => {
    try {
        const products = await Product.find();
        const user = req.user;
        res.render('user/about', { products, user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// หน้า login
router.get('/login', (req, res) => {
    res.render('user/login');
});

// เริ่มกระบวนการยืนยันตัวตนผ่าน Google
router.get('/auth/google', passport.authenticate('google', {
    scope: ['profile', 'email']
}));

router.get('/auth/google/redirect', passport.authenticate('google'), async (req, res) => {
    const user = req.user;

    if (user) {
        // บันทึก userId ลงในเซสชัน
        req.session.userId = user._id;

        // ตรวจสอบบทบาทของผู้ใช้
        if (user.role === 'admin') {
            return res.redirect('/admin'); // ถ้าเป็น admin
        } else {
            return res.redirect('/'); // ถ้าเป็น member ไปที่หน้า homepage
        }
    }
    res.redirect('/login'); // ถ้าไม่มีผู้ใช้ให้ไปที่หน้า login
});

// เส้นทาง logout
router.get('/logout', (req, res) => {
    req.logout((err) => {
        if (err) {
            return next(err);
        }
        res.redirect('/');
    });
});

router.post('/add-to-cart', async (req, res) => {
    const { id, quantity } = req.body;

    // ตรวจสอบว่าสินค้าอยู่ในฐานข้อมูลหรือไม่
    const product = await Product.findById(id);
    if (!product) {
        return res.status(404).json({ success: false, message: "Product not found" });
    }

    // ตรวจสอบว่าจำนวนต้องมากกว่า 0
    if (quantity <= 0) {
        return res.status(400).json({ success: false, message: "Quantity must be greater than 0" });
    }

    // ตรวจสอบว่ามีตะกร้าอยู่แล้วหรือไม่
    if (!req.session.cart) {
        req.session.cart = [];  // สร้างตะกร้าถ้ายังไม่มี
    }

    // ตรวจสอบว่ามีสินค้านี้อยู่ในตะกร้าหรือไม่
    const existingItem = req.session.cart.find(item => item.id === id);

    if (existingItem) {
        // หากจำนวนที่เพิ่มมากกว่าสต็อก ให้ไม่อนุญาตให้เพิ่ม
        if (existingItem.quantity + quantity > product.stock) {
            return res.status(400).json({ success: false, message: "Cannot exceed stock quantity" });
        }
        // เพิ่มจำนวนสินค้าในตะกร้า
        existingItem.quantity += quantity;
    } else {
        // ตรวจสอบว่าจำนวนที่เพิ่มไม่เกินสต็อก
        if (quantity > product.stock) {
            return res.status(400).json({ success: false, message: "Cannot exceed stock quantity" });
        }
        // เพิ่มสินค้าลงในตะกร้า
        req.session.cart.push({
            id,
            name: product.name,
            price: product.price,
            quantity
        });
    }

    // อัปเดตจำนวนสินค้าทั้งหมดในตะกร้า
    const totalItems = req.session.cart.reduce((total, item) => total + item.quantity, 0);

    // ส่งกลับ JSON พร้อมจำนวนสินค้า
    res.json({ success: true, totalItems });
});

// หน้าแสดงตะกร้าสินค้า
router.get('/cart', async (req, res) => {
    const cart = req.session.cart || []; // ดึงตะกร้าสินค้า
    const productIds = cart.map(item => item.id); // ดึง ID ของสินค้าในตะกร้า

    try {
        // ดึงข้อมูลสินค้าจาก MongoDB ตาม ID
        const products = await Product.find({ _id: { $in: productIds } });

        // รวมข้อมูลสินค้ากับตะกร้า
        const cartDetails = cart.map(cartItem => {
            const product = products.find(p => p._id.toString() === cartItem.id);
            return {
                name: product.name,
                price: product.price,
                stock: product.stock, // เพิ่มข้อมูลสต็อก
                quantity: cartItem.quantity,
                total: product.price * cartItem.quantity,
                id: cartItem.id // เพิ่ม id ของสินค้า
            };
        });

        // ส่งข้อมูลไปยังหน้า cart
        res.render('user/cart', { cart: cartDetails });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// ลบสินค้าออกจากตะกร้า
router.post('/remove-from-cart', (req, res) => {
    const { id } = req.body;

    // ลบสินค้า
    req.session.cart = req.session.cart.filter(item => item.id !== id);

    res.json({ success: true });
});

// อัปเดตจำนวนสินค้าในตะกร้า
router.post('/update-cart', (req, res) => {
    const cartUpdates = req.body; // array ของสินค้าและจำนวน

    cartUpdates.forEach(update => {
        const { id, quantity } = update; // id และจำนวนที่อัปเดต
        const item = req.session.cart.find(item => item.id === id);
        if (item) {
            // ตรวจสอบว่าจำนวนที่อัปเดตต้องมากกว่า 0
            if (quantity <= 0) {
                return res.status(400).json({ success: false, message: "Quantity must be greater than 0" });
            }

            // ตรวจสอบว่าจำนวนที่อัปเดตไม่เกิน stock
            if (quantity > Product.findById(id).stock) {
                return res.status(400).json({ success: false, message: "Cannot exceed stock quantity" });
            }

            item.quantity = quantity; // อัปเดตจำนวน
        }
    });

    res.json({ success: true });
});

//cart
router.post('/update-cart', async (req, res) => {
    const cartUpdates = req.body; // array ของสินค้าและจำนวน

    for (const update of cartUpdates) {
        const { id, quantity } = update; // id และจำนวนที่อัปเดต
        const item = req.session.cart.find(item => item.id === id);

        if (item) {
            // ตรวจสอบว่าจำนวนที่อัปเดตต้องมากกว่า 0
            if (quantity <= 0) {
                return res.status(400).json({ success: false, message: "จำนวนต้องมากกว่า 0" });
            }

            // ดึงข้อมูลสินค้าจากฐานข้อมูลเพื่อตรวจสอบ stock
            const product = await Product.findById(id);
            if (!product) {
                return res.status(404).json({ success: false, message: "ไม่เจอสินค้า" });
            }

            // ตรวจสอบว่าจำนวนที่อัปเดตไม่เกิน stock
            if (quantity > product.stock) {
                return res.status(400).json({ success: false, message: `จำนวนต้องอยู่ระหว่าง 1 ถึง ${product.stock}` });
            }

            // ตรวจสอบว่าจำนวนที่กรอกอยู่ระหว่าง 1 ถึง stock หรือไม่
            if (quantity < 1 || quantity > product.stock) {
                return res.status(400).json({ success: false, message: `เรียบร้อย` });
            }

            // อัปเดตจำนวนในตะกร้า
            item.quantity = quantity; // อัปเดตจำนวน
        }
    }

    res.json({ success: true });
});

router.post('/remove-from-cart', (req, res) => {
    const { id } = req.body;

    // ลบสินค้า
    req.session.cart = req.session.cart.filter(item => item.id !== id);

    res.json({ success: true });
});

router.get('/checkout', async (req, res) => {
    // ตรวจสอบว่าผู้ใช้ล็อกอินอยู่หรือไม่
    if (!req.session.userId) {
        return res.redirect('/login'); // หากไม่ได้ล็อกอิน ให้ส่งกลับไปหน้าล็อกอิน
    }

    try {
        const user = await User.findById(req.session.userId); // ดึงข้อมูลผู้ใช้จากฐานข้อมูล
        res.render('user/checkout', {
            cart: req.session.cart,
            user: user // ส่งข้อมูลผู้ใช้ไปยัง EJS
        });
    } catch (error) {
        console.error(error);
        res.redirect('/'); // ถ้าผิดพลาดให้กลับไปหน้าหลัก
    }
});

//order
router.post('/confirm-order', async (req, res) => {
    const { name, email, phone, address, items } = req.body;

    // ตรวจสอบว่าข้อมูลครบถ้วน
    if (!name || !email || !phone || !address || !items) {
        return res.json({ success: false, message: "User information is incomplete." });
    }

    try {
        // แปลง items ที่ส่งมาเป็นอาร์เรย์
        const orderItems = JSON.parse(items); // แปลง JSON เป็นอาร์เรย์

        // คำนวณยอดรวม
        const total = orderItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        // สร้างคำสั่งซื้อใหม่
        const newOrder = new Order({
            customer: {
                name,
                email,
                address,
                phone,
            },
            items: orderItems.map(item => ({
                product: item.product,
                quantity: item.quantity,
                price: item.price,
            })),
            total,
            status: 'Pending Payment' // ตั้งค่าสถานะเริ่มต้นเป็น Pending Payment
        });

        // บันทึกคำสั่งซื้อในฐานข้อมูล
        await newOrder.save();
        res.redirect('/');
        
    } catch (error) {
        console.error(error);
        return res.status(500).json({ success: false, message: "An error occurred while placing the order." });
    }
});

// รายการ order

router.get('/my-orders', async (req, res) => {
    if (!req.user) {
        return res.redirect('/login'); // Redirect to login if not authenticated
    }

    try {
        const orders = await Order.find({ 'customer.email': req.user.email }); // Find orders by user email
        res.render('user/my-orders', { orders, user: req.user }); // Pass the user object to the view
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Failed to retrieve orders." });
    }
});

//หลักฐานจ่ายเงิน

router.post('/upload-proof', upload.single('proof'), async (req, res) => {
    const proof = req.file; 
    const orderId = req.body.orderId;

    if (!proof) {
        return res.status(400).send('No file uploaded.'); 
    }

    try {
        // อัปเดตคำสั่งซื้อด้วยชื่อไฟล์ proof และเปลี่ยนสถานะเป็น Processing
        const updatedOrder = await Order.findByIdAndUpdate(
            orderId,
            {
                proofOfPayment: proof.filename,
                status: 'Processing' // เปลี่ยนสถานะเป็น Processing
            },
            { new: true } // คืนค่าอ็อบเจกต์ที่อัปเดตใหม่
        );

        // ตรวจสอบว่ามีคำสั่งซื้อนั้นหรือไม่
        if (!updatedOrder) {
            return res.status(404).send('Order not found.');
        }
        res.redirect('/my-orders');
        
    } catch (err) {
        console.error(err);
        res.status(500).send('Error updating order.'); // ตรวจสอบข้อผิดพลาดในการอัปเดตคำสั่งซื้อ
    }
});

//ยกเลิกรายการ

router.post('/cancel-order', async (req, res) => {
    const { orderId } = req.body;

    try {
        await Order.findByIdAndUpdate(orderId, { status: 'Cancelled' });
        res.redirect('/my-orders');
    } catch (error) {
        console.error(error);
        return res.status(500).json({ success: false, message: "An error occurred while cancelling the order." });
    }
});

//หน้าขอบคุณ

router.get('/thank-you', (req, res) => {
    res.render('user/thank-you');
});


module.exports = router;
