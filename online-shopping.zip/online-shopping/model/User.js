const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const userSchema = new Schema({
    googleId: {
        type: String,
        required: false
    },
    username: {
        type: String,
        required: false
    },
    thumbnail: {
        type: String
    },
    role: {
        type: String,
        enum: ['admin', 'member'],
        default: 'member'
    },
    password: {
        type: String,
        required: function () { return !this.googleId; }
    },
    email: {  // เพิ่มฟิลด์อีเมล
        type: String,
        required: false,  // ทำให้ไม่จำเป็นต้องกรอก
        unique: true // ทำให้ไม่สามารถมีอีเมลซ้ำกันได้
    }
});

module.exports = mongoose.model('User', userSchema);
