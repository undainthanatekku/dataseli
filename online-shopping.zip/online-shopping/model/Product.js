const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    description: { type: String },
    image: { type: String, required: true }, // URL ของรูปภาพ
    stock: { type: Number, required: true, default: 0 }, // จำนวนสต๊อกสินค้า
    createdAt: { type: Date, default: Date.now }, // วันที่สร้างสินค้า
    isRecommended: { type: Boolean, default: false } // ค่าการแนะนำ (default เป็น false)
});

// สร้างโมเดลจาก schema
const Product = mongoose.model('Product', productSchema);

module.exports = Product;
